
 *** Alpine Amp ***

 Made by tr909@bigfoot.com

 This is my first Winamp skin I made, I wonder
 were the FAQ's are for making skins. I couldn't
 find them, I all had to figure out where stuff
 had to come. 

 Many thanx to: 
  - Alpine website, for their Graphics (hehe)
  - poyta, for the really lame Alpine Skin v. 1.0
    (I couldn't stand that really lame skin and
    that is why I started this skin. respect to Alpine)
  - The guy from SpyAmp (007), for some of the main.bmp
    parts and mostly inspiration.
  - The guy from DeluxePlayer, for his REGION.TXT :)
  - And all others

 Alpine is a leading car-radio manufacturer
 with outstanding quality radio's (i prefer them
 over Pioneer because Alpine doesn't distort sound.
 (and mainly, your radio lights don't start 
 flashing when you put your Alpine very loud  :))


   �1998 by Tr909@bigfoot.com

 
