           ****COLD FUSION 2.01****
                designed by:
      Richie Jackson <rjackson97@aol.com
        http://www.tstonramp.com/~richj

9/27/98

>>COLD FUSION 2.01 RELEASED!!!!

  WHATS NEW:
     -- As you all know... when Winamp 2.01 came out
        there were changes in the "Skins" format.  This
        release takes into account those changes.
        I also took this time to add original buttons to
        The Playlist Editor and Equalizer.
        It really kicks.

9/18/98

>>COLD FUSION 2.0 RELEASED!!!!

  WHATS NEW:
     -- Playlist editor and equalizer are now skinned
        (Borrowed a couple buttons from    Comely Amp 
        and AmpRack... I am sure they will not mind.)
     -- Awesome new viscolor designed by Laird Bedore
        <bedore@eng.usf.edu>
     -- Some minor changes that do not need to be
        mentioned

8/25/98

>> A new viscolor was sent to me by Phantasmo3@aol.com
   it's pretty cool... the old viscolor is still 
   included in the zip file listed as
   original-viscolor.txt"

3/15/98

>> Lets Face It... Fusion AmpMan Kicks Anus!!  I wanted
   to make a skin based on Fusion AmpMan, making only a    few modifications.  I gave it a black display
   background, with blue writing, changing the viscolor
   as well. "Cold Fusion" was a fitting name I thought,
   seeing how it looks like "Fusion AmpMan" in a
   freezer.