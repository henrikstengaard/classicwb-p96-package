README.txt
~~~~~~~~~~

Introduction
------------
	Welcome to the ImageStudio PNG IO module. This module is
	currently the working version of the PNG module and is still
	not completely finished. It will not be fully complete until
	the PNG library, on which it is based, reaches v1.0. The
	current version is v0.6. This module should therefore be
	considered as "work in progress".

How to
------
	To install this module into ImageStudio 2.1.x, simply copy
	either 'PNG000.isio' or 'PNG020.isio' into the ImageStudio
	Modules/IO directory and restart ImageStudio. The '000'
	version should be used on Amigas with a 68000 processor, the
	'020' version can be used with 68020 and above.

Disclaimer
----------
	The authors are not responsible for any damage done or loss of
data caused by using this module.

Copyright
---------
	This package is freely distributable.

	All parts of this package are Copyright 1995 Andy Dean and
	Graham Dean.

The Authors
-----------
	The PNG module, and ImageStudio, is written by Andy Dean and
	Graham Dean.

	The PNG library is written by Group42 and is available via
	anonymous ftp at:

		ftp.uu.net /graphics/png

Graham is available at:

	14 Fielding Avenue
	Poynton
	Stockport
	Cheshire
	SK12 1YX
	ENGLAND

Andy is available via Email at:

	adean@eleceng.ucl.ac.uk

Documentation
-------------
	This is extracted from the ImageStudio documentation:

PNG
---

Name
     PNG

Load types
     Colour mapped, 24, 32 and 48bits.

Save types
     Colour mapped, 24bit.

Description
     PNG is the license free replacement for the GIF file format.

     After the controversy with the LZW compression algorithm used in
     the GIF file format, it was decided that a new standard should be
     created which uses the license free LZ compression algorithm along
     with many improvments over the GIF file format (e.g. support for
     24bit images). PNG is that format, and supports many advanced
     features to obtain the best lossless compression for any type of
     bitmap image. PNG also supports features that will find themselves
     useful in World Wide Web browsers, etc...

     A high degree of compatibility is obtained with our PNG
     loader/saver, as it is based in part on the PNGlib code by Group42.

ARexx OPEN command ARGS
     None.

ARexx SAVE command ARGS
     INTERLACE,TRANSPARENCY/S,TRANSPCOLOUR/N

    INTERLACE
	  By default PNG files are not interlaced, however by
	  specifying an INTERLACE value of ADAM7 they can be saved out
	  with 7 levels of interlacing. This gives progressive redraw
	  for World Wide Web browsers.

	  Note: This interlace has nothing to do with the Amiga's
	  interlaced screens.

    TRANSPARENCY/S
	  By specifying this switch, one colour out of the image's
	  pallete can be made `transparent', causing the background
	  colour to show through. This again can be useful with World
	  Wide Web browsers. By default, the transparent colour is
	  colour 0, but this can be changed (see below).

    TRANSPCOLOUR/N
	  This is the palette entry number that is made transparent if
	  the TRANSPARENT switch is used.

Example
     The following saves out a standard PNG format file:

	  SAVE FILE "Image.png" FORMAT "PNG"

     The following saves out a PNG file with interlace:

	  SAVE FILE "Image.png" FORMAT "PNG" ARGS "INTERLACE=ADAM7"

     The following saves out a PNG file with a transparent colour of 10:

	  SAVE FILE "Image.png" FORMAT "PNG",
	     ARGS "TRANSPARENCY TRANSPCOLOUR 10"
