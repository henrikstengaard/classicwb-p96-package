README.txt
~~~~~~~~~~
	There are a few points of interest you should know before installing
ImageStudio.

	o	If you are a registered user of ImageStudio v1.x.x, you
		may upgrade using this version. Simply select the
		'Create keyfile' option in the 'Project' menu of this
		version of ImageStudio. You will be asked to give your
		registered v1.x.x of ImageStudio, from which a personalised
		keyfile will be created. This keyfile will unlock this
		version of ImageStudio to work with full sized images.

		For more details, see the 'Upgrading from v1.x.x' in the
		'Introduction' section of the documentation.

	o	The ImageStudio disks must be called "ImageStudio_1",
		"ImageStudio_2" etc... in order for the installer script
		to work.

	o	LX, used to decompress the files during installation, has
		been found to crash on some machines. If you find the installer
		crashes, perform the following:

		i)	Make a copy of ImageStudio_1 disk.
		ii)	Delete LX from the disk.
		iii)	Copy LHA onto the disk and rename it LX.
		iv)	Install again.

		This of course assumes that you have the LHA compressor
		program handy. We cannot distribute LHA ourselves, as this
		is not allowed by LHA's author.
