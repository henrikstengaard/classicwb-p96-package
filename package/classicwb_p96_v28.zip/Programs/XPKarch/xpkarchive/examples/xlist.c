#include <stdio.h>
#include <stdlib.h>

#include "/include/libraries/xpkarchive.h"

struct XarArchiverEntry a[100];

struct Library *XpkArchiveBase;

main()
{
   long cnt,i;

   if(XpkArchiveBase=OpenLibrary("xpkarctest.library",0)) {

      cnt=XarQuery(XAR_ArchiversQuery,a,XAR_ArraySize,100,TAG_DONE);

      for(i=0;i<cnt;i++) {

         printf("%s %d\n",a[i].Packer,a[i].Type);
      }

      CloseLibrary(XpkArchiveBase);
   }
   return EXIT_SUCCESS;
}




