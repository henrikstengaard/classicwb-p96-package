#include <stdlib.h>
#include <stdio.h>

#include <libraries/xpkarchive.h>

struct Library *XpkArchiveBase;

main(int argc,char *argv[])
{
   char *p;
   int og=0,ng=0;
   XarHandle *arc;
   LONG Error;

   XpkArchiveBase=OpenLibrary("xpkarctest.library",1);
   if(!XpkArchiveBase) {
      fprintf(stderr,"Cannot open xpkarctest.library\n");
      exit(0);
   }

   if(argc!=4) {
      fprintf(stderr,"Usage: %s <arc> <oldname> <newname>\n",argv[0]);
      goto fail1;
   }

   if(!(arc=XarOpenArchive(XAR_ArchiveName,argv[1],
                           XAR_ShowDirs,TRUE,
                           XAR_Error,&Error,TAG_DONE))) {
      fprintf(stderr,"Cannot open archive\n");
      goto fail1;
   }


   if(p=rindex(argv[2],',')) {
      *p=0;
      sscanf(p+1,"%d",&og);
      og--;
   }
   if(p=rindex(argv[3],',')) {
      *p=0;
      sscanf(p+1,"%d",&ng);
      ng--;
   }


   printf("%s,%d  %s,%d\n",argv[2],og+1,argv[3],ng+1);

   printf("R: %ld\n",XarRenameFile(XAR_Archive,arc,
                               XAR_FileName,argv[2],
                               XAR_Generation,og,
                               XAR_NewName,argv[3],
                               XAR_NewGeneration,ng,
                               TAG_DONE));

   XarCloseArchive(arc);
fail1:
   CloseLibrary(XpkArchiveBase);
   exit(0);

}













