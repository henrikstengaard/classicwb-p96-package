/* xQuery - Query packer properties */

char ver[]="$VER: xQuery 1.1 ("__DATE__")";

#include <proto/exec.h>
#include <proto/dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <libraries/xpkarchive.h>

struct Library *XpkArchiveBase;
char errbuf[XPKERRMSGSIZE];
char line1[200], line2[200], line3[200], line4[200], line5[200];

void print(char *s) { Write(Output(),s,strlen(s));}

void end( char *text )
{
   if( text )    print( text );
   if( XpkArchiveBase ) CloseLibrary( XpkArchiveBase );
   exit(text ? 10 : 0);
}

int breakfunc(void)
{
   end("***Break\n");
   return 0;
}

void
packerquery(char *packer)
{
   struct  XarArchiverInfo xpinfo;
   XMINFO xminfo;
   LONG   mode, res, n;
   char   buf[20];

   onbreak(breakfunc);
   printf("\23332mPacker :\233m %s\n",packer);

   if( res=XarQuery(
      XAR_ArchiverQuery, &xpinfo,
      XAR_PackMethod, packer,
       TAG_DONE
   ))
      return;

   printf("\23332mName   :\233m %s\n",xpinfo.LongName);
   printf("\23332mDescr. :\233m %s\n",xpinfo.Description);
   printf("\23332mDefMode:\233m %d\n",xpinfo.DefaultMode);

   for( mode=0, n=0; mode<100; mode=xminfo.Upto+1, n++ ) {
      if( XarQuery(
         XAR_ModeQuery,  &xminfo,
         XAR_PackMethod, packer,
         XAR_PackMode,   mode,
         TAG_DONE
      ))
         break;

      strcpy(buf,"           ");
      strcpy(buf+(9-strlen(xminfo.Description))/2,xminfo.Description);
      sprintf( line1+9*n,"%3ld..%-3ld ",mode,xminfo.Upto);
      sprintf( line2+9*n,"%-9.9s ",     buf);
      sprintf( line3+9*n,"%4ld K/s  ",  xminfo.PackSpeed);
      sprintf( line4+9*n,"%4ld K/s  ",  xminfo.UnpackSpeed);
      sprintf( line5+9*n,"%4ld %%   ",  xminfo.Ratio/10);
   }
   printf("\23332mMode   :\233m %s\n", line1 );
   printf("\23332mDescr. :\233m %s\n", line2 );
   printf("\23332mPkSpeed:\233m %s\n", line3 );
   printf("\23332mUpSpeed:\233m %s\n", line4 );
   printf("\23332mRatio  :\233m %s\n", line5 );

   printf("\n");
}


void main(int argc, char *argv[])
{
   static struct XarArchiverEntry list[100];
   LONG   i,NumPackers;

   if(!(XpkArchiveBase=OpenLibrary("xpkarctest.library",2)))
      end("Cannot open xpkarctest.library\n");

   NumPackers=XarQuery( XAR_ArchiversQuery, list, XAR_ArraySize,100, TAG_DONE );

   if( argc==1 )
      for( i=0; i<NumPackers; i++ )
         packerquery( list[i].Packer );
   else
      for( i=1; i<argc; i++ )
         packerquery( argv[i] );

   end(NULL);
}
