/* derived from: zoomem.h 2.1 87/12/25 12:26:18 */
/* $Path$ */
/* $Id: zoomem.h,v 1.3 91/07/09 01:43:06 dhesi Exp $ */

/*
(C) Copyright 1991 Rahul Dhesi -- All rights reserved

Defines parameters used for memory allocation.
*/


extern char *out_buf_adr;              /* global I/O buffer */

/*************************************************************/
/* DO NOT CHANGE THE REST OF THIS FILE.                      */
/*************************************************************/

/*
The main I/O buffer (called in_buf_adr in zoo.c) is reused
in several places.
*/

#define  IN_BUF_SIZE       8192
#define  OUT_BUF_SIZE      8192

/* MEM_BLOCK_SIZE must be no less than (2 * DICSIZ + MAXMATCH)
(see ar.h and lzh.h for values).  The buffer of this size will
also hold an input buffer of IN_BUF_SIZE and an output buffer
of OUT_BUF_SIZE.  FUDGE is a fudge factor, to keep some spare and
avoid off-by-one errors. */

#define FUDGE      8
#define  MEM_BLOCK_SIZE    (8192 + 8192 + 256 + 8)

